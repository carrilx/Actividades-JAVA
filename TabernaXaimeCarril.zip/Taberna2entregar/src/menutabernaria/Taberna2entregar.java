package menutabernaria;

import java.util.Scanner;

/**
 * Programa de gestión para "A Taberna da Ría"
 * @author carri
 */
public class Taberna2entregar {

    // Constantes de precios
    public static final double PRECIO_BEBIDA = 2.50;
    public static final double PRECIO_COMIDA = 10.00;
    public static final double PRECIO_HABITA = 10.00;

    public static void main(String[] args) {
        Scanner miScanner = new Scanner(System.in);

        // Variables para contabilizar ingresos
        double ingresosAluguer = 0;
        double ingresosBebidasComidas = 0;
        boolean tabernaAberta = true;

        // Mensajes de bienvenida
        System.out.println("¡Benvido/a á Taberna da Ría!");
        System.out.println("Xestiona a túa taberna con sabedoría...\n");

        // Bucle principal
        do {
            System.out.println("=== MENÚ DA TABERNA ===");
            System.out.println("1. Atender cliente (servir comida/bebida)");
            System.out.println("2. Alugar habitación");
            System.out.println("3. Ver ingresos totais obtidos");
            System.out.println("4. Pechar a taberna");
            System.out.print("Elixe unha opción: ");

            // Validación de entrada para evitar crashes
            int opcion;
            if (miScanner.hasNextInt()) {
                opcion = miScanner.nextInt();
            } else {
                miScanner.next(); // Limpiar buffer
                opcion = -1; // Opción inválida
            }

            switch (opcion) {
                case 1:
                    // Atender cliente y acumular ingresos
                    double ingresoCliente = atenderCliente(miScanner);
                    ingresosBebidasComidas += ingresoCliente;
                    break;

                case 2:
                    // Alugar habitación y acumular ingresos
                    double ingresoHabitacion = alugarHabitacion(miScanner);
                    ingresosAluguer += ingresoHabitacion;
                    break;

                case 3:
                    // Ver estadísticas
                    verEstatisticas(ingresosAluguer, ingresosBebidasComidas);
                    break;

                case 4:
                    // Cerrar taberna
                    tabernaAberta = false;
                    break;

                default:
                    System.out.println("Opción non válida. Por favor, elixe unha opción correcta.\n");
            }

        } while (tabernaAberta);

        // Mensaje de despedida
        System.out.println("\n¡Bo descanso, mañá será outro día!");
        miScanner.close(); // Cerrar Scanner al final
    }

    /**
     * Muestra las estadísticas de ingresos de la taberna
     * @param ingresosAluguer Total de ingresos por alquiler
     * @param ingresosBebidasComidas Total de ingresos por comidas y bebidas
     */
    public static void verEstatisticas(double ingresosAluguer, double ingresosBebidasComidas) {
        double gananciasT = ingresosAluguer + ingresosBebidasComidas;
        
        System.out.println("\n=== ESTATÍSTICAS DA TABERNA ===");
        System.out.println("Ingresos obtidos por comidas/bebidas: " + ingresosBebidasComidas + " €");
        System.out.println("Ingresos obtidos polo aluguer: " + ingresosAluguer + " €");
        System.out.println("Ganancias totais: " + gananciasT + " €\n");
    }

    /**
     * Atiende a un cliente tomando su comanda de bebidas y comidas
     * @param scanner Scanner compartido desde el main
     * @return Total de ingresos generados por este cliente
     */
    public static double atenderCliente(Scanner scanner) {
        double totalComidas = 0.0;
        double totalBebidas = 0.0;
        int opcionComanda;

        do {
            System.out.println("\n--- Comanda ---");
            System.out.println("1. Comida (" + PRECIO_COMIDA + " €)");
            System.out.println("2. Bebida (" + PRECIO_BEBIDA + " €)");
            System.out.println("3. Finalizar");
            System.out.print("Elixe unha opción: ");

            // Validación de entrada
            if (scanner.hasNextInt()) {
                opcionComanda = scanner.nextInt();
            } else {
                scanner.next(); // Limpiar buffer
                opcionComanda = -1; // Opción inválida
            }

            if (opcionComanda == 1) {
                // Servir comidas
                System.out.print("Cantos menús?: ");
                if (scanner.hasNextInt()) {
                    int numMenus = scanner.nextInt();
                    if (numMenus > 0) {
                        double costoComidas = numMenus * PRECIO_COMIDA;
                        totalComidas += costoComidas;
                        System.out.println("Serviches " + numMenus + " menús que supón un ingreso de " 
                                         + costoComidas + " €\n");
                    } else {
                        System.out.println("Número non válido.\n");
                    }
                } else {
                    scanner.next(); // Limpiar buffer
                    System.out.println("Entrada non válida.\n");
                }

            } else if (opcionComanda == 2) {
                // Servir bebidas
                System.out.print("Cantas bebidas?: ");
                if (scanner.hasNextInt()) {
                    int numBebidas = scanner.nextInt();
                    if (numBebidas > 0) {
                        double costoBebidas = numBebidas * PRECIO_BEBIDA;
                        totalBebidas += costoBebidas;
                        System.out.println("Serviches " + numBebidas + " bebidas que supón un ingreso de " 
                                         + costoBebidas + " €\n");
                    } else {
                        System.out.println("Número non válido.\n");
                    }
                } else {
                    scanner.next(); // Limpiar buffer
                    System.out.println("Entrada non válida.\n");
                }

            } else if (opcionComanda == 3) {
                // Finalizar comanda
                System.out.println("Comanda finalizada.\n");

            } else {
                System.out.println("Opción non válida. Por favor, elixe unha opción correcta.\n");
            }

        } while (opcionComanda != 3);

        // Devolver total de ingresos por este cliente
        return totalComidas + totalBebidas;
    }

    /**
     * Alquila una habitación al cliente
     * @param scanner Scanner compartido desde el main
     * @return Costo total del alquiler
     */
    public static double alugarHabitacion(Scanner scanner) {
        double costoTotal = 0.0;

        System.out.println("\n--- Aluguer de Habitación ---");
        System.out.print("Cantas noites vai hospedarse o cliente?: ");

        // Validación de entrada
        if (scanner.hasNextInt()) {
            int noites = scanner.nextInt();

            if (noites > 0) {
                costoTotal = noites * PRECIO_HABITA;
                System.out.println("Habitación alugada por " + noites + " noites");
                System.out.println("Costo total: " + costoTotal + " €\n");
            } else {
                System.out.println("Número de noites non válido. Non se realizou o aluguer.\n");
            }
        } else {
            scanner.next(); // Limpiar buffer
            System.out.println("Entrada non válida. Non se realizou o aluguer.\n");
        }

        return costoTotal;
    }
}